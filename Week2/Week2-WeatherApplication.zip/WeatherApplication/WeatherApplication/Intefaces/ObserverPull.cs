﻿namespace WeatherApplication.Intefaces
{
    public interface ObserverPull
    {
        int ID { get; set; }
        void Update();
    }
}
